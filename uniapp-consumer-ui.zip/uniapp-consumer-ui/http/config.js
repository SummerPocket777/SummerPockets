const config={
	baseUrl:'http://110.41.178.59:8081',
	timeOut:6000,
	env:'dev'
}

export default config;