<template>
	<view>
		点餐页面
		<view>
			<dishbox></dishbox>
			<dishbox></dishbox>
			<dishbox></dishbox>
			
			
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss">

</style>
